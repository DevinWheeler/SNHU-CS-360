package com.example.project_two;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Initialize the database
        database = openOrCreateDatabase("AppDatabase", MODE_PRIVATE, null);
        createDatabase();

        // Handle login button click
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        // Handle create account button click
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }
        });
    }

    private void createDatabase() {
        // Create user table if not exists
        String createUserTable = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, password TEXT)";
        database.execSQL(createUserTable);
    }

    private void login() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Query the database for the user
        String query = "SELECT id FROM users WHERE username = ? AND password = ?";
        Cursor cursor = database.rawQuery(query, new String[]{username, password});

        if (cursor.moveToFirst()) {
            // Retrieve the user ID
            int userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));

            // Successful login
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

            // Navigate to the next activity, passing the user ID
            Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
            intent.putExtra("userId", String.valueOf(userId));
            startActivity(intent);
        } else {
            // Failed login
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }

    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Insert user into the database
            String insertQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
            database.execSQL(insertQuery, new Object[]{username, password});

            Toast.makeText(this, "Account created successfully! You can now log in.", Toast.LENGTH_SHORT).show();
            // Clear the fields for the next action
            usernameEditText.setText("");
            passwordEditText.setText("");
        } catch (Exception e) {
            // Handle case where the username already exists
            Toast.makeText(this, "Username already exists. Please choose a different one.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (database != null) {
            database.close();
        }
    }
}
