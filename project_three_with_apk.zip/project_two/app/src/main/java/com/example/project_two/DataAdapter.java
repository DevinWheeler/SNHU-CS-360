package com.example.project_two;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.DataViewHolder> {

    private final List<WeightEntry> entries; // List of data
    private final OnDeleteClickListener deleteClickListener; // Interface for delete action

    // Interface for delete click listener
    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    // Constructor to initialize entries and delete listener
    public DataAdapter(List<WeightEntry> entries, OnDeleteClickListener deleteClickListener) {
        this.entries = entries;
        this.deleteClickListener = deleteClickListener;
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new DataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {

        WeightEntry entry = entries.get(position);


        holder.weightTextView.setText(entry.getWeight());
        holder.dateTextView.setText(entry.getDate());


        holder.deleteButton.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(position); // Notify activity/fragment
            }
        });
    }

    @Override
    public int getItemCount() {
        return entries.size(); // Number of rows
    }

    public static class DataViewHolder extends RecyclerView.ViewHolder {
        TextView weightTextView; // TextView for weight
        TextView dateTextView;   // TextView for date
        ImageButton deleteButton; // ImageButton for delete action

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize views
            weightTextView = itemView.findViewById(R.id.weightTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
