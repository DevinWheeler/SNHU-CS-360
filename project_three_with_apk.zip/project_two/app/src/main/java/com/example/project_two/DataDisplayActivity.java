package com.example.project_two;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataDisplayActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "AppPreferences";
    private static final String TARGET_WEIGHT_KEY = "targetWeight";
    private static final String SMS_PERMISSION_KEY = "smsPermissionGranted";
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    private RecyclerView recyclerView;
    private DataAdapter adapter;
    private List<WeightEntry> entries;
    private DatabaseCrud databaseCrud;
    private TextView targetWeightDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Get userId
        String userId = getIntent().getStringExtra("userId");

        // Initialize UI components
        targetWeightDisplay = findViewById(R.id.targetWeightDisplay);
        recyclerView = findViewById(R.id.dataGridRecyclerView);
        FloatingActionButton addButton = findViewById(R.id.addButton);

        // Initialize the database
        databaseCrud = new DatabaseCrud(this);

        // Load user-specific entries
        entries = databaseCrud.getAllEntries(userId);

        // Set up RecyclerView
        adapter = new DataAdapter(entries, position -> {
            WeightEntry entry = entries.get(position);
            databaseCrud.deleteEntry(entry.getId());
            entries.clear();
            entries.addAll(databaseCrud.getAllEntries(userId));
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        addButton.setOnClickListener(v -> showAddRowDialog(userId));

        loadTargetWeight();

        checkAndRequestSmsPermission();

        Button changeTargetWeightButton = findViewById(R.id.updateTargetWeightButton); // Ensure this ID matches your layout
        changeTargetWeightButton.setOnClickListener(v -> {
            showUpdateTargetWeightDialog();
        });
    }

    private void loadTargetWeight() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String targetWeight = preferences.getString(TARGET_WEIGHT_KEY, "00.0 lbs");
        targetWeightDisplay.setText("Target Weight: " + targetWeight);
    }

    private void saveTargetWeight(String weight) {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(TARGET_WEIGHT_KEY, weight);
        editor.apply();
    }

    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            saveSmsPermissionChoice(true);
            Toast.makeText(this, "SMS notifications are enabled", Toast.LENGTH_SHORT).show();
        } else {
            SharedPreferences preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            boolean isPermissionGranted = preferences.getBoolean(SMS_PERMISSION_KEY, false);

            if (!isPermissionGranted) {
                showPermissionDialog();
            }
        }
    }

    private void showPermissionDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_sms_permission, null);

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setView(dialogView).setCancelable(true);

        android.app.AlertDialog dialog = builder.create();

        Button btnGrantPermission = dialogView.findViewById(R.id.btnGrantPermission);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);

        btnGrantPermission.setOnClickListener(v -> {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
            dialog.dismiss();
        });

        btnCancel.setOnClickListener(v -> {
            saveSmsPermissionChoice(false);
            dialog.dismiss();
        });

        dialog.show();
    }

    private void saveSmsPermissionChoice(boolean isGranted) {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(SMS_PERMISSION_KEY, isGranted);
        editor.apply();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSmsPermissionChoice(true);
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                saveSmsPermissionChoice(false);
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showAddRowDialog(String userId) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_row, null);

        EditText weightInput = dialogView.findViewById(R.id.weightInput);
        EditText dateInput = dialogView.findViewById(R.id.dateInput);
        Button addButton = dialogView.findViewById(R.id.addButton);
        Button cancelButton = dialogView.findViewById(R.id.cancelButton);

        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        dateInput.setText(currentDate);

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setView(dialogView);
        android.app.AlertDialog dialog = builder.create();

        addButton.setOnClickListener(v -> {
            String weight = weightInput.getText().toString();
            String date = dateInput.getText().toString();

            if (!weight.isEmpty() && !date.isEmpty()) {
                databaseCrud.addEntry(userId, weight, date);
                entries.clear();
                entries.addAll(databaseCrud.getAllEntries(userId));
                adapter.notifyDataSetChanged();

                // Check if the entered weight matches the target weight
                SharedPreferences preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                String targetWeight = preferences.getString(TARGET_WEIGHT_KEY, "75.0 lbs").replace(" lbs", "");
                boolean isSmsEnabled = preferences.getBoolean(SMS_PERMISSION_KEY, false);

                try {
                    double enteredWeight = Double.parseDouble(weight);
                    double targetWeightValue = Double.parseDouble(targetWeight);

                    if (enteredWeight <= targetWeightValue) {
                        Toast.makeText(this, "Congratulations! You've gone below your target weight!", Toast.LENGTH_SHORT).show();

                        if (isSmsEnabled) {
                            sendCongratulatorySms();
                        }
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid weight format. Please check the target or entered weight.", Toast.LENGTH_SHORT).show();
                }

                dialog.dismiss();
                Toast.makeText(this, "Entry added", Toast.LENGTH_SHORT).show();
            } else {
                if (weight.isEmpty()) {
                    weightInput.setError("Please enter a valid weight");
                }
                if (date.isEmpty()) {
                    dateInput.setError("Please enter a valid date");
                }
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }


    private void sendCongratulatorySms() {
        try {
            String phoneNumber = "1234567890";
            String message = "Congratulations! You've reached your target weight! Keep up the great work!";

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }



    private void showUpdateTargetWeightDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_update_weight, null);

        EditText newTargetWeightInput = dialogView.findViewById(R.id.newTargetWeightInput);
        Button updateButton = dialogView.findViewById(R.id.updateButton);
        Button cancelButton = dialogView.findViewById(R.id.cancelButton);

        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setView(dialogView);
        android.app.AlertDialog dialog = builder.create();

        updateButton.setOnClickListener(v -> {
            String newTargetWeight = newTargetWeightInput.getText().toString();
            if (!newTargetWeight.isEmpty()) {
                saveTargetWeight(newTargetWeight + " lbs");
                loadTargetWeight();
                dialog.dismiss();
                Toast.makeText(this, "Target weight updated", Toast.LENGTH_SHORT).show();
            } else {
                newTargetWeightInput.setError("Please enter a valid weight");
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }
}
