package com.example.project_two;

public class WeightEntry {
    private final int id;      // Unique ID for the entry
    private final String weight; // Weight value
    private final String date;   // Date value


    public WeightEntry(int id, String weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public WeightEntry(String weight, String date) {
        this.id = -1; // Default ID for entries that don't yet exist in the database
        this.weight = weight;
        this.date = date;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }
}
